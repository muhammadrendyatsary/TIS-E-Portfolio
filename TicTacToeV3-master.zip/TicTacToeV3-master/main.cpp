#include "Game.hpp"

int main() {
    Game ticTacToe;
    ticTacToe.run();
    return 0;
}